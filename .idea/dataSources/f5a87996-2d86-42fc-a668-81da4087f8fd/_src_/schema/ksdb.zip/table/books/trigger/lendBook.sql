CREATE TRIGGER lendBook
AFTER UPDATE ON books
FOR EACH ROW
  BEGIN
UPDATE lender
SET amount = ifnull(lender.amount ,0)+1
WHERE id = new.isLend;
  INSERT INTO test (v1) VALUES (new.isLend);
END;
